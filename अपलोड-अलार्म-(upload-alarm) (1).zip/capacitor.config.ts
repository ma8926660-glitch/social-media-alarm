import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.yourname.socialalarm',
  appName: 'Social Media Alarm',
  webDir: 'dist'
};

export default config;
