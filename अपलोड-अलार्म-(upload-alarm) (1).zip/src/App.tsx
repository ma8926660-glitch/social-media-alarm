import { useState, useEffect, useRef } from 'react';
import { Alarm, Platform, UploadRecord, AppSettings } from './types';
import {
  storageService,
  formatDateKey,
  calculateStreaks,
} from './services/storageService';
import { audioService } from './services/audioService';
import { notificationService } from './services/notificationService';
import { TopNav } from './components/TopNav';
import { AlarmList } from './components/AlarmList';
import { StreakStats } from './components/StreakStats';
import { AlarmFormModal } from './components/AlarmFormModal';
import { FullScreenAlert } from './components/FullScreenAlert';
import { PlatformsModal } from './components/PlatformsModal';
import { SettingsModal } from './components/SettingsModal';
import { NotificationBanner } from './components/NotificationBanner';

export default function App() {
  // Core persisted state
  const [platforms, setPlatforms] = useState<Platform[]>(() => storageService.getPlatforms());
  const [alarms, setAlarms] = useState<Alarm[]>(() => storageService.getAlarms());
  const [uploads, setUploads] = useState<UploadRecord[]>(() => storageService.getUploads());
  const [settings, setSettings] = useState<AppSettings>(() => storageService.getSettings());

  // Navigation & Modals
  const [activeView, setActiveView] = useState<'alarms' | 'streak'>('alarms');
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingAlarm, setEditingAlarm] = useState<Alarm | null>(null);
  const [isPlatformsModalOpen, setIsPlatformsModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [showNotifBanner, setShowNotifBanner] = useState(() => {
    return notificationService.getPermissionStatus() === 'default';
  });

  // Active Ringing Alarm state
  const [activeRingingAlarm, setActiveRingingAlarm] = useState<{
    alarm: Alarm;
    platform: Platform;
  } | null>(null);

  // Snoozed alarms tracker: list of { alarm: Alarm; triggerAt: number }
  const snoozedListRef = useRef<{ alarm: Alarm; triggerAt: number }[]>([]);

  // Track the last minute each alarm was triggered to prevent repeating in same minute
  const lastTriggerMinuteRef = useRef<Record<string, string>>({});

  // Sync dark mode class on document element
  useEffect(() => {
    if (settings.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings.darkMode]);

  // Audio Context unlocker on user's first interaction
  useEffect(() => {
    const unlockHandler = () => {
      audioService.unlockAudio();
      audioService.setVolume(settings.volume);
    };
    window.addEventListener('click', unlockHandler, { once: true });
    window.addEventListener('touchstart', unlockHandler, { once: true });
    return () => {
      window.removeEventListener('click', unlockHandler);
      window.removeEventListener('touchstart', unlockHandler);
    };
  }, [settings.volume]);

  // Main Alarm Checker Loop (every 1000ms)
  useEffect(() => {
    const interval = window.setInterval(() => {
      const now = new Date();
      const currentHH = String(now.getHours()).padStart(2, '0');
      const currentMM = String(now.getMinutes()).padStart(2, '0');
      const currentTimeStr = `${currentHH}:${currentMM}`;
      const currentDayIndex = now.getDay(); // 0 = Sun ... 6 = Sat
      const todayDateKey = formatDateKey(now);
      const triggerKeyMinute = `${todayDateKey}_${currentTimeStr}`;

      // 1. Check Snoozed Alarms first
      const snoozedIndex = snoozedListRef.current.findIndex(
        (item) => now.getTime() >= item.triggerAt
      );
      if (snoozedIndex !== -1 && !activeRingingAlarm) {
        const snoozedItem = snoozedListRef.current[snoozedIndex];
        snoozedListRef.current.splice(snoozedIndex, 1);

        const targetPlatform =
          platforms.find((p) => p.id === snoozedItem.alarm.platformId) || platforms[0];
        triggerAlarmAlert(snoozedItem.alarm, targetPlatform);
        return;
      }

      // 2. Check Scheduled Alarms
      if (activeRingingAlarm) return; // Don't interrupt if already ringing

      for (const alarm of alarms) {
        if (!alarm.enabled) continue;

        // Check time match
        if (alarm.time === currentTimeStr) {
          // Check repeat day match (empty array means Daily)
          const isDayMatched =
            alarm.repeatDays.length === 0 || alarm.repeatDays.includes(currentDayIndex);

          if (isDayMatched) {
            // Check if already triggered during this exact minute
            if (lastTriggerMinuteRef.current[alarm.id] === triggerKeyMinute) {
              continue;
            }

            // Mark as triggered for this minute
            lastTriggerMinuteRef.current[alarm.id] = triggerKeyMinute;

            const targetPlatform =
              platforms.find((p) => p.id === alarm.platformId) || platforms[0];

            triggerAlarmAlert(alarm, targetPlatform);
            break;
          }
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [alarms, platforms, activeRingingAlarm, settings]);

  // Function to ring the alarm
  const triggerAlarmAlert = (alarm: Alarm, platform: Platform) => {
    setActiveRingingAlarm({ alarm, platform });

    // 1. Play looping audio if sound enabled
    if (settings.soundEnabled) {
      audioService.setVolume(settings.volume);
      audioService.startAlarmLoop(alarm.soundType || settings.soundType);
    }

    // 2. Vibrate if enabled and supported
    if (settings.vibrationEnabled) {
      notificationService.startVibration([400, 200, 400, 200, 600]);
    }

    // 3. Send browser notification
    notificationService.sendNotification(
      `${platform.name}: Time to upload your video!`,
      {
        body: alarm.note
          ? `Note: ${alarm.note}`
          : `Upload your video on ${platform.name} and keep your streak alive!`,
        tag: `social-media-alarm-${alarm.id}`,
      }
    );
  };

  // Stop active ringing
  const stopActiveAlert = () => {
    audioService.stopAlarm();
    notificationService.stopVibration();
    setActiveRingingAlarm(null);
  };

  // Handle "Done" button on alert
  const handleAlertDone = (alarm: Alarm, platform: Platform) => {
    stopActiveAlert();
    const newRecord = storageService.addUpload(
      platform.id,
      platform.name,
      alarm.note || 'Upload completed'
    );
    setUploads([newRecord, ...uploads]);
  };

  // Handle "Snooze 10 min" button on alert
  const handleAlertSnooze = (alarm: Alarm) => {
    stopActiveAlert();
    const snoozeTime = Date.now() + 10 * 60 * 1000; // 10 minutes later
    snoozedListRef.current.push({
      alarm,
      triggerAt: snoozeTime,
    });
  };

  // Handle manual test alarm
  const handleTestAlarm = (alarm: Alarm) => {
    audioService.unlockAudio();
    const platform = platforms.find((p) => p.id === alarm.platformId) || platforms[0];
    triggerAlarmAlert(alarm, platform);
  };

  // Alarm management
  const handleToggleAlarm = (id: string) => {
    const updated = alarms.map((a) => (a.id === id ? { ...a, enabled: !a.enabled } : a));
    setAlarms(updated);
    storageService.saveAlarms(updated);
  };

  const handleDeleteAlarm = (id: string) => {
    if (window.confirm('Are you sure you want to delete this alarm?')) {
      const updated = alarms.filter((a) => a.id !== id);
      setAlarms(updated);
      storageService.saveAlarms(updated);
    }
  };

  const handleSaveAlarm = (
    alarmData: Omit<Alarm, 'id' | 'createdAt'>,
    editingId?: string
  ) => {
    let updated: Alarm[];
    if (editingId) {
      updated = alarms.map((a) =>
        a.id === editingId ? { ...a, ...alarmData } : a
      );
    } else {
      const newAlarm: Alarm = {
        ...alarmData,
        id: 'alarm_' + Date.now(),
        createdAt: Date.now(),
      };
      updated = [...alarms, newAlarm];
    }
    setAlarms(updated);
    storageService.saveAlarms(updated);
    setIsFormModalOpen(false);
    setEditingAlarm(null);
  };

  // Manual upload from Streak section
  const handleManualUpload = (platformId: string, note?: string) => {
    const platform = platforms.find((p) => p.id === platformId) || platforms[0];
    const newRecord = storageService.addUpload(
      platform.id,
      platform.name,
      note || 'Manual upload recorded'
    );
    setUploads([newRecord, ...uploads]);
  };

  const handleClearHistory = () => {
    if (window.confirm('Are you sure you want to clear upload history? This will reset your streak.')) {
      storageService.saveUploads([]);
      setUploads([]);
    }
  };

  // Reset all data to factory defaults
  const handleResetAllData = () => {
    storageService.resetAllData();
    window.location.reload();
  };

  // Request notifications from banner
  const handleAllowNotifications = async () => {
    const granted = await notificationService.requestPermission();
    setShowNotifBanner(false);
    if (granted) {
      notificationService.sendNotification('Social Media Alarm Enabled!', {
        body: 'You will now receive timely reminders for all your video uploads.',
      });
    }
  };

  const { currentStreak } = calculateStreaks(uploads);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors pb-24 md:pb-12">
      {/* Top Bar with Top Bar Contract */}
      <TopNav
        activeView={activeView}
        onSelectView={setActiveView}
        onOpenPlatforms={() => setIsPlatformsModalOpen(true)}
        onOpenSettings={() => setIsSettingsModalOpen(true)}
        onCreateAlarm={() => {
          setEditingAlarm(null);
          setIsFormModalOpen(true);
        }}
        darkMode={settings.darkMode}
        onToggleTheme={() => {
          const updated = { ...settings, darkMode: !settings.darkMode };
          setSettings(updated);
          storageService.saveSettings(updated);
        }}
        streakCount={currentStreak}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 pt-6 sm:pt-8">
        {/* First Launch Notification Banner */}
        {showNotifBanner && (
          <NotificationBanner
            onAllow={handleAllowNotifications}
            onDismiss={() => setShowNotifBanner(false)}
          />
        )}

        {/* View Switch: Alarms vs Streak */}
        {activeView === 'alarms' ? (
          <AlarmList
            alarms={alarms}
            platforms={platforms}
            onToggleAlarm={handleToggleAlarm}
            onEditAlarm={(alarm) => {
              setEditingAlarm(alarm);
              setIsFormModalOpen(true);
            }}
            onDeleteAlarm={handleDeleteAlarm}
            onCreateAlarm={() => {
              setEditingAlarm(null);
              setIsFormModalOpen(true);
            }}
            onTestAlarm={handleTestAlarm}
          />
        ) : (
          <StreakStats
            uploads={uploads}
            platforms={platforms}
            onManualUpload={handleManualUpload}
            onClearHistory={handleClearHistory}
          />
        )}
      </main>

      {/* Full-Screen Ringing Alert Modal */}
      {activeRingingAlarm && (
        <FullScreenAlert
          alarm={activeRingingAlarm.alarm}
          platform={activeRingingAlarm.platform}
          onDone={handleAlertDone}
          onSnooze={handleAlertSnooze}
          onStop={stopActiveAlert}
        />
      )}

      {/* Create / Edit Alarm Modal */}
      {isFormModalOpen && (
        <AlarmFormModal
          initialAlarm={editingAlarm}
          platforms={platforms}
          onSave={handleSaveAlarm}
          onClose={() => {
            setIsFormModalOpen(false);
            setEditingAlarm(null);
          }}
          onOpenPlatformsManager={() => {
            setIsFormModalOpen(false);
            setIsPlatformsModalOpen(true);
          }}
        />
      )}

      {/* Platforms Manager Modal */}
      {isPlatformsModalOpen && (
        <PlatformsModal
          platforms={platforms}
          onSavePlatforms={(updated) => {
            setPlatforms(updated);
            storageService.savePlatforms(updated);
          }}
          onClose={() => setIsPlatformsModalOpen(false)}
        />
      )}

      {/* Settings Modal */}
      {isSettingsModalOpen && (
        <SettingsModal
          settings={settings}
          onUpdateSettings={(newSettings) => {
            setSettings(newSettings);
            storageService.saveSettings(newSettings);
          }}
          onResetAllData={handleResetAllData}
          onClose={() => setIsSettingsModalOpen(false)}
        />
      )}
    </div>
  );
}
