export interface Platform {
  id: string;
  name: string;
  nameEn: string;
  color: string;
  bgColor: string;
  textColor: string;
  iconName: 'youtube' | 'facebook' | 'instagram' | 'tiktok' | 'twitter' | 'linkedin' | 'sharechat' | 'globe' | 'video' | 'camera';
  isCustom?: boolean;
}

export type SoundType = 'digital' | 'chime' | 'energy' | 'radar';

export interface Alarm {
  id: string;
  platformId: string;
  time: string; // "HH:mm" in 24-hr format (e.g. "18:30")
  repeatDays: number[]; // 0 = Sun, 1 = Mon, ..., 6 = Sat. Empty array = daily
  note?: string;
  enabled: boolean;
  soundType: SoundType;
  createdAt: number;
  lastTriggeredDate?: string; // "YYYY-MM-DD"
}

export interface UploadRecord {
  id: string;
  platformId: string;
  platformName: string;
  timestamp: number; // Unix timestamp
  dateString: string; // "YYYY-MM-DD"
  note?: string;
}

export interface AppSettings {
  soundEnabled: boolean;
  soundType: SoundType;
  volume: number; // 0 to 1
  vibrationEnabled: boolean;
  darkMode: boolean;
}
