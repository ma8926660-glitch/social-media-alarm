import React, { useState } from 'react';
import { Platform } from '../types';
import { PlatformIcon } from './PlatformIcon';
import { DEFAULT_PLATFORMS } from '../services/storageService';
import { X, Plus, Trash2, RotateCcw, Check } from 'lucide-react';

interface PlatformsModalProps {
  platforms: Platform[];
  onSavePlatforms: (updated: Platform[]) => void;
  onClose: () => void;
}

const PRESET_COLORS = [
  '#EF4444', // Red
  '#F97316', // Orange
  '#F59E0B', // Amber
  '#10B981', // Emerald
  '#06B6D4', // Cyan
  '#3B82F6', // Blue
  '#6366F1', // Indigo
  '#8B5CF6', // Purple
  '#EC4899', // Pink
  '#111827', // Dark Slate
];

const AVAILABLE_ICONS: Platform['iconName'][] = [
  'video',
  'camera',
  'globe',
  'youtube',
  'instagram',
  'facebook',
  'tiktok',
  'twitter',
  'linkedin',
  'sharechat',
];

export const PlatformsModal: React.FC<PlatformsModalProps> = ({
  platforms,
  onSavePlatforms,
  onClose,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newColor, setNewColor] = useState(PRESET_COLORS[0]);
  const [newIcon, setNewIcon] = useState<Platform['iconName']>('video');

  const handleAddPlatform = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    const newPlatform: Platform = {
      id: 'custom_' + Date.now(),
      name: newName.trim(),
      nameEn: newName.trim(),
      color: newColor,
      bgColor: 'bg-slate-800',
      textColor: 'text-white',
      iconName: newIcon,
      isCustom: true,
    };

    onSavePlatforms([...platforms, newPlatform]);
    setNewName('');
    setShowAddForm(false);
  };

  const handleDeletePlatform = (id: string) => {
    onSavePlatforms(platforms.filter((p) => p.id !== id));
  };

  const handleResetDefaults = () => {
    if (window.confirm('Do you want to restore the default platform list?')) {
      onSavePlatforms(DEFAULT_PLATFORMS);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="platforms-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4 overflow-y-auto"
    >
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div>
            <h2 id="platforms-modal-title" className="text-lg font-bold text-slate-900 dark:text-white">
              Social Media Platforms
            </h2>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Add custom channels or manage platforms
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1">
          {/* Action row */}
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={() => setShowAddForm(!showAddForm)}
              className="text-xs font-bold px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Custom Platform</span>
            </button>

            <button
              type="button"
              onClick={handleResetDefaults}
              className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Defaults</span>
            </button>
          </div>

          {/* Add Platform Form */}
          {showAddForm && (
            <form
              onSubmit={handleAddPlatform}
              className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-4 animate-in fade-in duration-150"
            >
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                New Custom Platform
              </h3>

              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                  Platform Name*
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Pinterest, Threads, Twitch"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-rose-500"
                />
              </div>

              {/* Color Presets */}
              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block mb-1.5">
                  Brand Theme Color
                </label>
                <div className="flex flex-wrap gap-2 items-center">
                  {PRESET_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setNewColor(c)}
                      className={`w-7 h-7 rounded-full flex items-center justify-center transition-transform cursor-pointer ${
                        newColor === c ? 'scale-110 ring-2 ring-offset-2 ring-slate-800 dark:ring-white' : ''
                      }`}
                      style={{ backgroundColor: c }}
                    >
                      {newColor === c && <Check className="w-3.5 h-3.5 text-white" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Icon Presets */}
              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block mb-1.5">
                  Select Icon
                </label>
                <div className="flex flex-wrap gap-2">
                  {AVAILABLE_ICONS.map((icon) => (
                    <button
                      key={icon}
                      type="button"
                      onClick={() => setNewIcon(icon)}
                      className={`w-9 h-9 rounded-xl border flex items-center justify-center transition-all cursor-pointer ${
                        newIcon === icon
                          ? 'border-rose-500 bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 ring-2 ring-rose-500/20'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-slate-400'
                      }`}
                    >
                      <PlatformIcon iconName={icon} className="w-4 h-4" />
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold rounded-lg bg-rose-600 hover:bg-rose-700 text-white cursor-pointer"
                >
                  Save Platform
                </button>
              </div>
            </form>
          )}

          {/* Platform List */}
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {platforms.map((p) => (
              <div key={p.id} className="py-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-white shrink-0 shadow-sm"
                    style={{ backgroundColor: p.color }}
                  >
                    <PlatformIcon iconName={p.iconName} className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <span className="text-sm font-bold text-slate-900 dark:text-white block truncate">
                      {p.name}
                    </span>
                    <span className="text-xs text-slate-500 dark:text-slate-400 block truncate">
                      {p.isCustom ? 'Custom Platform' : 'Default Platform'}
                    </span>
                  </div>
                </div>

                {p.isCustom ? (
                  <button
                    type="button"
                    onClick={() => handleDeletePlatform(p.id)}
                    className="min-h-[40px] min-w-[40px] p-2 text-slate-400 hover:text-rose-600 rounded-lg transition-colors flex items-center justify-center cursor-pointer"
                    title="Delete Platform"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                ) : (
                  <span className="text-[11px] text-slate-400 px-2 py-1">Default</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
