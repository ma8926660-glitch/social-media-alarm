import React, { useState } from 'react';
import { Alarm, Platform, SoundType } from '../types';
import { PlatformIcon } from './PlatformIcon';
import { DAYS_OF_WEEK, formatTimeEnglish } from '../utils/timeUtils';
import { audioService } from '../services/audioService';
import { X, Clock, Bell, Volume2, Sparkles, Check } from 'lucide-react';

interface AlarmFormModalProps {
  initialAlarm?: Alarm | null;
  platforms: Platform[];
  onSave: (alarmData: Omit<Alarm, 'id' | 'createdAt'>, editingId?: string) => void;
  onClose: () => void;
  onOpenPlatformsManager: () => void;
}

const QUICK_TIMES = [
  { label: '09:00', hint: '9:00 AM' },
  { label: '12:00', hint: '12:00 PM' },
  { label: '15:30', hint: '3:30 PM' },
  { label: '18:00', hint: '6:00 PM' },
  { label: '19:30', hint: '7:30 PM' },
  { label: '21:00', hint: '9:00 PM' },
];

const SOUND_OPTIONS: { type: SoundType; label: string; desc: string }[] = [
  { type: 'energy', label: 'Energy Chime', desc: 'Motivational ascending melody' },
  { type: 'digital', label: 'Digital Beep', desc: 'Classic electronic double beep' },
  { type: 'chime', label: 'Soft Chime', desc: 'Gentle harmonic bell chime' },
  { type: 'radar', label: 'Radar Pulse', desc: 'High-attention alert sweep' },
];

const QUICK_NOTES = [
  'Upload new Shorts / Reel',
  'Main long-form video',
  'Post community update',
  'Start live stream',
  'Trending audio reel',
];

export const AlarmFormModal: React.FC<AlarmFormModalProps> = ({
  initialAlarm,
  platforms,
  onSave,
  onClose,
  onOpenPlatformsManager,
}) => {
  const [platformId, setPlatformId] = useState<string>(
    initialAlarm?.platformId || platforms[0]?.id || 'youtube'
  );
  const [time, setTime] = useState<string>(initialAlarm?.time || '18:00');
  const [repeatDays, setRepeatDays] = useState<number[]>(initialAlarm?.repeatDays || []);
  const [note, setNote] = useState<string>(initialAlarm?.note || '');
  const [soundType, setSoundType] = useState<SoundType>(initialAlarm?.soundType || 'energy');
  const [playingPreview, setPlayingPreview] = useState<SoundType | null>(null);

  const toggleDay = (dayIndex: number) => {
    if (repeatDays.includes(dayIndex)) {
      setRepeatDays(repeatDays.filter((d) => d !== dayIndex));
    } else {
      setRepeatDays([...repeatDays, dayIndex].sort());
    }
  };

  const handleDailyClick = () => {
    // Empty array represents "Daily"
    setRepeatDays([]);
  };

  const handlePreviewSound = (type: SoundType) => {
    setPlayingPreview(type);
    audioService.playPreview(type);
    setTimeout(() => {
      setPlayingPreview(null);
    }, 1200);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(
      {
        platformId,
        time,
        repeatDays,
        note: note.trim(),
        enabled: true,
        soundType,
      },
      initialAlarm?.id
    );
  };

  const selectedPlatform = platforms.find((p) => p.id === platformId) || platforms[0];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="alarm-modal-title"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/70 backdrop-blur-sm p-0 sm:p-4 overflow-y-auto"
    >
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 flex items-center justify-center">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h2 id="alarm-modal-title" className="text-lg font-bold text-slate-900 dark:text-white">
                {initialAlarm ? 'Edit Alarm' : 'New Alarm'}
              </h2>
              <span className="text-xs text-slate-600 dark:text-slate-400">
                Choose upload time and social platform
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 overflow-y-auto flex-1">
          {/* 1. Platform Selection */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400">
                1. Social Media Platform
              </label>
              <button
                type="button"
                onClick={onOpenPlatformsManager}
                className="text-xs font-semibold text-rose-600 dark:text-rose-400 hover:underline cursor-pointer"
              >
                + Manage Platforms
              </button>
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {platforms.map((p) => {
                const isSelected = p.id === platformId;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPlatformId(p.id)}
                    className={`min-h-[58px] p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all text-center cursor-pointer ${
                      isSelected
                        ? 'border-rose-500 bg-rose-50/50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-300 ring-2 ring-rose-500/20 font-semibold shadow-sm'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900/60'
                    }`}
                  >
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center text-white"
                      style={{ backgroundColor: p.color }}
                    >
                      <PlatformIcon iconName={p.iconName} className="w-4 h-4" />
                    </div>
                    <span className="text-xs truncate w-full">{p.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Time Selection */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label htmlFor="alarm-time-input" className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400">
                2. Alarm Time
              </label>
              <span className="text-xs font-semibold text-rose-600 dark:text-rose-400">
                {formatTimeEnglish(time)}
              </span>
            </div>

            <div className="relative mb-2.5">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Clock className="w-5 h-5" />
              </div>
              <input
                id="alarm-time-input"
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                required
                className="w-full pl-11 pr-4 py-3 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tabular-nums focus:outline-none focus:ring-2 focus:ring-rose-500"
              />
            </div>

            {/* Quick Time Presets */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
              <span className="text-slate-500 shrink-0 mr-1">Quick:</span>
              {QUICK_TIMES.map((qt) => (
                <button
                  key={qt.label}
                  type="button"
                  onClick={() => setTime(qt.label)}
                  className={`px-2.5 py-1 rounded-lg border whitespace-nowrap cursor-pointer transition-colors ${
                    time === qt.label
                      ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 border-transparent font-medium'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-400'
                  }`}
                >
                  {qt.hint}
                </button>
              ))}
            </div>
          </div>

          {/* 3. Repeat Days */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400">
                3. Repeat Days
              </label>
              <button
                type="button"
                onClick={handleDailyClick}
                className={`text-xs font-medium px-2 py-0.5 rounded cursor-pointer transition-colors ${
                  repeatDays.length === 0
                    ? 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 font-bold'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {repeatDays.length === 0 ? '✓ Daily Active' : 'Set to Daily'}
              </button>
            </div>

            <div className="grid grid-cols-7 gap-1.5">
              {DAYS_OF_WEEK.map((day) => {
                const isIndividualActive = repeatDays.includes(day.index);
                return (
                  <button
                    key={day.index}
                    type="button"
                    onClick={() => toggleDay(day.index)}
                    className={`min-h-[44px] rounded-xl text-xs font-bold flex flex-col items-center justify-center transition-all cursor-pointer border ${
                      isIndividualActive
                        ? 'bg-rose-500 border-rose-600 text-white shadow-sm'
                        : repeatDays.length === 0
                        ? 'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300'
                        : 'bg-slate-100 dark:bg-slate-800 border-transparent text-slate-500 dark:text-slate-400 hover:bg-slate-200'
                    }`}
                  >
                    <span>{day.short}</span>
                  </button>
                );
              })}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1.5">
              {repeatDays.length === 0
                ? 'Empty selection will trigger the alarm daily (every day).'
                : 'Alarm will ring on the selected days only.'}
            </p>
          </div>

          {/* 4. Alarm Sound Melody */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 block mb-2">
              4. Alarm Sound (Web Audio API)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {SOUND_OPTIONS.map((opt) => {
                const isSelected = soundType === opt.type;
                const isPreviewing = playingPreview === opt.type;
                return (
                  <div
                    key={opt.type}
                    onClick={() => setSoundType(opt.type)}
                    className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                      isSelected
                        ? 'border-rose-500 bg-rose-50/40 dark:bg-rose-950/20 text-rose-950 dark:text-rose-100 ring-1 ring-rose-500/20'
                        : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                    }`}
                  >
                    <div className="min-w-0 pr-2">
                      <div className="text-xs font-bold flex items-center gap-1.5">
                        {isSelected && <Check className="w-3.5 h-3.5 text-rose-500 shrink-0" />}
                        <span className="truncate">{opt.label}</span>
                      </div>
                      <span className="text-[10px] text-slate-500 dark:text-slate-400 truncate block">
                        {opt.desc}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePreviewSound(opt.type);
                      }}
                      className={`min-h-[36px] min-w-[36px] rounded-lg p-1.5 flex items-center justify-center transition-colors ${
                        isPreviewing
                          ? 'bg-rose-500 text-white animate-pulse'
                          : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-300'
                      }`}
                      title="Preview Sound"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 5. Note / Caption Description */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label htmlFor="alarm-note-input" className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400">
                5. Note or Caption (Optional)
              </label>
              <span className="text-xs text-slate-500 dark:text-slate-400">e.g. New reel, shorts</span>
            </div>

            <input
              id="alarm-note-input"
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder={`e.g. Upload new video on ${selectedPlatform.name}`}
              maxLength={120}
              className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-rose-500 mb-2"
            />

            {/* Quick Note Suggestions */}
            <div className="flex flex-wrap gap-1.5">
              {QUICK_NOTES.map((qn) => (
                <button
                  key={qn}
                  type="button"
                  onClick={() => setNote(qn)}
                  className="text-[11px] px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400 cursor-pointer transition-colors"
                >
                  + {qn}
                </button>
              ))}
            </div>
          </div>

          {/* Sticky Form Save Button (Min 48px hitbox) */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full min-h-[50px] px-6 py-3 rounded-xl bg-rose-600 hover:bg-rose-700 active:scale-[0.98] text-white font-bold text-base flex items-center justify-center gap-2 shadow-lg shadow-rose-600/20 transition-all cursor-pointer"
            >
              <Sparkles className="w-5 h-5" />
              <span>{initialAlarm ? 'Save Changes' : 'Set Alarm'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
