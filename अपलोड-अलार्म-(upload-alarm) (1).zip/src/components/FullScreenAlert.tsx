import React, { useEffect } from 'react';
import { Alarm, Platform } from '../types';
import { PlatformIcon } from './PlatformIcon';
import { formatTimeEnglish } from '../utils/timeUtils';
import { Bell, CheckCircle2, Clock, XCircle, Volume2 } from 'lucide-react';
import confetti from 'canvas-confetti';

interface FullScreenAlertProps {
  alarm: Alarm;
  platform: Platform;
  onDone: (alarm: Alarm, platform: Platform) => void;
  onSnooze: (alarm: Alarm) => void;
  onStop: () => void;
}

export const FullScreenAlert: React.FC<FullScreenAlertProps> = ({
  alarm,
  platform,
  onDone,
  onSnooze,
  onStop,
}) => {
  // Prevent background scrolling while ringing
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = '';
    };
  }, []);

  const handleDoneClick = () => {
    // Fire celebratory confetti for keeping streak alive!
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6'],
      });
    } catch {
      // Ignore
    }
    onDone(alarm, platform);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Social Media Upload Alert"
      className="fixed inset-0 z-50 flex flex-col justify-between bg-slate-950 text-white p-6 sm:p-8 animate-in fade-in duration-200 overflow-y-auto"
      style={{
        backgroundImage: `radial-gradient(circle at 50% 25%, ${platform.color}40 0%, transparent 70%)`,
      }}
    >
      {/* Top Bar with Live Indicator */}
      <div className="flex items-center justify-between w-full max-w-xl mx-auto pt-2">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur-md text-xs font-semibold text-white/90 border border-white/15">
          <Volume2 className="w-4 h-4 text-rose-400 animate-pulse" />
          <span>Alarm Ringing</span>
        </div>
        <div className="text-right">
          <span className="text-xs text-white/60 font-mono tracking-wider">
            {new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      </div>

      {/* Main Alert Center */}
      <div className="flex flex-col items-center justify-center text-center my-auto py-8 max-w-lg mx-auto w-full">
        {/* Animated Pulsing Ring & Platform Icon */}
        <div className="relative mb-6">
          <div
            className="absolute inset-0 rounded-full animate-pulse-ring opacity-50"
            style={{ backgroundColor: platform.color }}
          />
          <div
            className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl flex items-center justify-center shadow-2xl transition-transform active:scale-95"
            style={{ backgroundColor: platform.color }}
          >
            <PlatformIcon iconName={platform.iconName} className="w-14 h-14 sm:w-16 sm:h-16 text-white drop-shadow-md" />
            <div className="absolute -top-2 -right-2 w-9 h-9 rounded-full bg-white text-slate-950 flex items-center justify-center shadow-lg animate-bounce">
              <Bell className="w-5 h-5 fill-rose-500 text-rose-500" />
            </div>
          </div>
        </div>

        {/* Platform Name Badge */}
        <span
          className="text-xs uppercase font-bold tracking-wider px-3 py-1 rounded-md mb-2"
          style={{ backgroundColor: `${platform.color}30`, color: '#ffffff' }}
        >
          {platform.name}
        </span>

        <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white mb-3 text-balance leading-tight">
          Time to upload on {platform.name}!
        </h1>

        <div className="text-sm sm:text-base text-slate-300 font-medium mb-4 flex items-center gap-2">
          <span>Scheduled Time: {formatTimeEnglish(alarm.time)}</span>
        </div>

        {/* User Note if Available */}
        {alarm.note ? (
          <div className="w-full bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/15 text-left mb-6">
            <span className="text-xs font-semibold uppercase tracking-wider text-white/60 block mb-1">
              Note / Caption:
            </span>
            <p className="text-base text-white font-medium leading-relaxed">
              "{alarm.note}"
            </p>
          </div>
        ) : (
          <div className="w-full bg-white/5 rounded-2xl p-3 border border-white/10 text-center mb-6 text-xs text-white/70">
            Publish your content now and tap Done to keep your streak alive!
          </div>
        )}
      </div>

      {/* Action Buttons (Large Touch-Friendly Hitboxes >= 48px) */}
      <div className="w-full max-w-lg mx-auto pb-4 space-y-3">
        {/* Primary Done Button */}
        <button
          type="button"
          onClick={handleDoneClick}
          className="w-full min-h-[56px] px-6 py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-600 active:scale-[0.98] text-white font-bold text-lg sm:text-xl flex items-center justify-center gap-3 shadow-xl shadow-emerald-500/25 transition-all cursor-pointer"
        >
          <CheckCircle2 className="w-6 h-6 shrink-0" />
          <span>Done (Count Streak)</span>
        </button>

        <div className="grid grid-cols-2 gap-3">
          {/* Snooze Button */}
          <button
            type="button"
            onClick={() => onSnooze(alarm)}
            className="w-full min-h-[50px] px-4 py-3 rounded-2xl bg-white/15 hover:bg-white/20 active:scale-[0.98] text-white font-semibold text-sm sm:text-base flex items-center justify-center gap-2 border border-white/20 transition-all cursor-pointer"
          >
            <Clock className="w-4 h-4 text-amber-300 shrink-0" />
            <span>Snooze 10 min</span>
          </button>

          {/* Stop Button */}
          <button
            type="button"
            onClick={onStop}
            className="w-full min-h-[50px] px-4 py-3 rounded-2xl bg-rose-500/20 hover:bg-rose-500/30 active:scale-[0.98] text-rose-200 hover:text-white font-semibold text-sm sm:text-base flex items-center justify-center gap-2 border border-rose-500/30 transition-all cursor-pointer"
          >
            <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>Stop</span>
          </button>
        </div>
      </div>
    </div>
  );
};
