import React from 'react';
import { Bell, Flame, Sliders, Settings, Plus, Sun, Moon } from 'lucide-react';

interface TopNavProps {
  activeView: 'alarms' | 'streak';
  onSelectView: (view: 'alarms' | 'streak') => void;
  onOpenPlatforms: () => void;
  onOpenSettings: () => void;
  onCreateAlarm: () => void;
  darkMode: boolean;
  onToggleTheme: () => void;
  streakCount: number;
}

export const TopNav: React.FC<TopNavProps> = ({
  activeView,
  onSelectView,
  onOpenPlatforms,
  onOpenSettings,
  onCreateAlarm,
  darkMode,
  onToggleTheme,
  streakCount,
}) => {
  return (
    <>
      {/* Desktop & Tablet Top Bar (Strict 3-zone contract) */}
      <header className="sticky top-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 sm:gap-8">
          {/* Zone 1: Brand Wordmark (Single-element Brand Zone) */}
          <div className="flex items-center gap-2.5 shrink-0">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-500 text-white flex items-center justify-center shadow-md shadow-rose-500/20">
              <Bell className="w-5 h-5 fill-white" />
            </div>
            <button
              type="button"
              onClick={() => onSelectView('alarms')}
              className="text-left cursor-pointer"
            >
              <span className="text-lg font-black tracking-tight text-slate-900 dark:text-white whitespace-nowrap block leading-tight">
                Social Media Alarm
              </span>
            </button>
          </div>

          {/* Zone 2: Navigation Links (single-line, clean text) */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-600 dark:text-slate-400">
            <button
              type="button"
              onClick={() => onSelectView('alarms')}
              className={`transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                activeView === 'alarms'
                  ? 'text-rose-600 dark:text-rose-400 font-bold'
                  : 'hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Bell className="w-4 h-4" />
              <span>Alarms</span>
            </button>

            <button
              type="button"
              onClick={() => onSelectView('streak')}
              className={`transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                activeView === 'streak'
                  ? 'text-rose-600 dark:text-rose-400 font-bold'
                  : 'hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
              <span>Streak ({streakCount} {streakCount === 1 ? 'Day' : 'Days'})</span>
            </button>

            <button
              type="button"
              onClick={onOpenPlatforms}
              className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5"
            >
              <Sliders className="w-4 h-4" />
              <span>Platforms</span>
            </button>

            <button
              type="button"
              onClick={onOpenSettings}
              className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5"
            >
              <Settings className="w-4 h-4" />
              <span>Settings</span>
            </button>
          </nav>

          {/* Zone 3: 1 Primary Action + Quick Theme Switch */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button
              type="button"
              onClick={onToggleTheme}
              title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              className="min-h-[40px] min-w-[40px] p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition-colors cursor-pointer"
              aria-label="Toggle theme"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={onCreateAlarm}
              className="min-h-[44px] px-3.5 sm:px-4 py-2 text-xs sm:text-sm font-bold text-white bg-rose-600 hover:bg-rose-700 active:scale-95 rounded-xl shadow-md shadow-rose-600/20 transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span className="hidden sm:inline">New Alarm</span>
              <span className="sm:hidden">Alarm</span>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Fixed Bottom Tab Bar (English tabs: Alarms, Streak, Platforms, Settings) */}
      <nav
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-lg border-t border-slate-200 dark:border-slate-800 grid grid-cols-4 items-center h-16 pb-safe px-2"
      >
        <button
          type="button"
          onClick={() => onSelectView('alarms')}
          className={`flex flex-col items-center justify-center h-full min-h-[44px] cursor-pointer ${
            activeView === 'alarms'
              ? 'text-rose-600 dark:text-rose-400 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Bell className="w-5 h-5" />
          <span className="text-[11px] font-semibold mt-1">Alarms</span>
        </button>

        <button
          type="button"
          onClick={() => onSelectView('streak')}
          className={`flex flex-col items-center justify-center h-full min-h-[44px] cursor-pointer ${
            activeView === 'streak'
              ? 'text-rose-600 dark:text-rose-400 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <div className="relative">
            <Flame className="w-5 h-5 fill-amber-500 text-amber-500" />
            {streakCount > 0 && (
              <span className="absolute -top-1 -right-2 text-[9px] font-black bg-rose-600 text-white rounded-full px-1">
                {streakCount}
              </span>
            )}
          </div>
          <span className="text-[11px] font-semibold mt-1">Streak</span>
        </button>

        <button
          type="button"
          onClick={onOpenPlatforms}
          className="flex flex-col items-center justify-center h-full min-h-[44px] text-slate-500 dark:text-slate-400 cursor-pointer"
        >
          <Sliders className="w-5 h-5" />
          <span className="text-[11px] font-semibold mt-1">Platforms</span>
        </button>

        <button
          type="button"
          onClick={onOpenSettings}
          className="flex flex-col items-center justify-center h-full min-h-[44px] text-slate-500 dark:text-slate-400 cursor-pointer"
        >
          <Settings className="w-5 h-5" />
          <span className="text-[11px] font-semibold mt-1">Settings</span>
        </button>
      </nav>
    </>
  );
};
