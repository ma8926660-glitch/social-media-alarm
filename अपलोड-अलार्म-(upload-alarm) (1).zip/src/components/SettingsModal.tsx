import React, { useState } from 'react';
import { AppSettings, SoundType } from '../types';
import { notificationService } from '../services/notificationService';
import { audioService } from '../services/audioService';
import { X, Moon, Sun, Bell, Volume2, Smartphone, RotateCcw, Check, Play } from 'lucide-react';

interface SettingsModalProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onResetAllData: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onResetAllData,
  onClose,
}) => {
  const [notifPermission, setNotifPermission] = useState<string>(
    notificationService.getPermissionStatus()
  );
  const [testingSound, setTestingSound] = useState(false);

  const handleRequestNotif = async () => {
    const granted = await notificationService.requestPermission();
    setNotifPermission(notificationService.getPermissionStatus());
    if (granted) {
      notificationService.sendNotification('Social Media Alarm Enabled!', {
        body: 'You will receive reminders when it is time to upload your videos.',
      });
    }
  };

  const handleTestSound = (type: SoundType) => {
    setTestingSound(true);
    audioService.setVolume(settings.volume);
    audioService.playPreview(type);
    setTimeout(() => {
      setTestingSound(false);
    }, 1200);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="settings-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4 overflow-y-auto"
    >
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div>
            <h2 id="settings-modal-title" className="text-lg font-bold text-slate-900 dark:text-white">
              App Settings
            </h2>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Customize sound, notifications, and appearance
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1 text-sm">
          {/* 1. Dark Mode / Light Mode */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-300">
                {settings.darkMode ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
              </div>
              <div>
                <span className="font-bold text-slate-900 dark:text-white block">
                  Dark Mode
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  {settings.darkMode ? 'Dark theme active' : 'Light theme active'}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onUpdateSettings({ ...settings, darkMode: !settings.darkMode })}
              className={`w-12 h-7 rounded-full p-1 transition-colors cursor-pointer ${
                settings.darkMode ? 'bg-rose-600' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                  settings.darkMode ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* 2. Notifications Permission */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Bell className="w-5 h-5 text-rose-500" />
                <span className="font-bold text-slate-900 dark:text-white">
                  Browser Notifications
                </span>
              </div>

              <span
                className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                  notifPermission === 'granted'
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    : notifPermission === 'denied'
                    ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                    : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                }`}
              >
                {notifPermission === 'granted'
                  ? 'Active'
                  : notifPermission === 'denied'
                  ? 'Denied'
                  : 'Pending'}
              </span>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-400">
              Receive upload alerts on time even if the app tab is in the background.
            </p>

            {notifPermission !== 'granted' ? (
              <button
                type="button"
                onClick={handleRequestNotif}
                className="w-full min-h-[40px] px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>Grant Notification Permission</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() =>
                  notificationService.sendNotification('Social Media Alarm Test', {
                    body: 'This is a test notification. Upload alerts are functioning properly!',
                  })
                }
                className="w-full min-h-[40px] px-3.5 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-800 dark:text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <span>Send Test Notification</span>
              </button>
            )}
          </div>

          {/* 3. Audio Volume & Test */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Volume2 className="w-5 h-5 text-rose-500" />
                <span className="font-bold text-slate-900 dark:text-white">
                  Alarm Volume
                </span>
              </div>
              <span className="text-xs font-bold text-slate-600 dark:text-slate-300 tabular-nums">
                {Math.round(settings.volume * 100)}%
              </span>
            </div>

            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={settings.volume}
              onChange={(e) => {
                const vol = parseFloat(e.target.value);
                audioService.setVolume(vol);
                onUpdateSettings({ ...settings, volume: vol });
              }}
              className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-rose-600"
            />

            <div className="flex items-center justify-between pt-1">
              <span className="text-xs text-slate-500">Preview Melody:</span>
              <button
                type="button"
                onClick={() => handleTestSound(settings.soundType)}
                className="min-h-[36px] px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Play className={`w-3.5 h-3.5 ${testingSound ? 'text-rose-500' : ''}`} />
                <span>Play Sound</span>
              </button>
            </div>
          </div>

          {/* 4. Vibration Toggle */}
          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-300">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-slate-900 dark:text-white block">
                  Device Vibration
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  Vibrate device when alarm sounds
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                const nextVal = !settings.vibrationEnabled;
                if (nextVal) {
                  notificationService.startVibration([200, 100, 200]);
                  setTimeout(() => notificationService.stopVibration(), 600);
                }
                onUpdateSettings({ ...settings, vibrationEnabled: nextVal });
              }}
              className={`w-12 h-7 rounded-full p-1 transition-colors cursor-pointer ${
                settings.vibrationEnabled ? 'bg-rose-600' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                  settings.vibrationEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* 5. Reset Data */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => {
                if (window.confirm('Are you sure you want to reset all alarms, uploads, and streak records?')) {
                  onResetAllData();
                }
              }}
              className="w-full py-2.5 rounded-xl border border-rose-200 dark:border-rose-900/60 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset All Data</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
