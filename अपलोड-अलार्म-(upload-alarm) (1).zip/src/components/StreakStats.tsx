import React, { useState } from 'react';
import { UploadRecord, Platform } from '../types';
import { PlatformIcon } from './PlatformIcon';
import { calculateStreaks, formatDateKey } from '../services/storageService';
import { DAYS_OF_WEEK } from '../utils/timeUtils';
import { Flame, Award, BarChart3, Plus, CheckCircle2, History } from 'lucide-react';
import confetti from 'canvas-confetti';

interface StreakStatsProps {
  uploads: UploadRecord[];
  platforms: Platform[];
  onManualUpload: (platformId: string, note?: string) => void;
  onClearHistory?: () => void;
}

export const StreakStats: React.FC<StreakStatsProps> = ({
  uploads,
  platforms,
  onManualUpload,
  onClearHistory,
}) => {
  const { currentStreak, bestStreak, totalUploads, uploadedToday } = calculateStreaks(uploads);
  const [selectedPlatformId, setSelectedPlatformId] = useState<string>(platforms[0]?.id || 'youtube');
  const [customNote, setCustomNote] = useState<string>('');
  const [showManualForm, setShowManualForm] = useState<boolean>(false);

  // Compute 7-day stats (from 6 days ago up to today)
  const now = new Date();
  const past7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(now);
    d.setDate(now.getDate() - (6 - i));
    const dateKey = formatDateKey(d);
    const dayOfWeek = d.getDay();
    const dayName = DAYS_OF_WEEK[dayOfWeek]?.short || '';
    const dayUploads = uploads.filter((u) => u.dateString === dateKey);

    return {
      dateKey,
      dayName,
      dateNum: d.getDate(),
      count: dayUploads.length,
      isToday: i === 6,
      items: dayUploads,
    };
  });

  const maxDayCount = Math.max(...past7Days.map((d) => d.count), 4);

  // Platform-wise uploads calculation
  const platformCounts: { platform: Platform; count: number }[] = platforms
    .map((p) => {
      const count = uploads.filter((u) => u.platformId === p.id).length;
      return { platform: p, count };
    })
    .sort((a, b) => b.count - a.count);

  const handleQuickUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
      });
    } catch {
      // Ignore
    }
    onManualUpload(selectedPlatformId, customNote || undefined);
    setCustomNote('');
    setShowManualForm(false);
  };

  return (
    <div className="space-y-6">
      {/* 1. Primary Streak & Achievement Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        {/* Streak Counter Card */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-amber-500/10 via-rose-500/10 to-transparent dark:from-amber-950/30 dark:via-rose-950/20 border border-amber-200/60 dark:border-amber-800/40 p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
              Current Streak
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Flame className="w-5 h-5 fill-amber-500" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-4xl sm:text-5xl font-black text-slate-900 dark:text-white tabular-nums">
              {currentStreak}
            </span>
            <span className="text-base sm:text-lg font-bold text-amber-600 dark:text-amber-400">
              Days in a row
            </span>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400 mt-2">
            {uploadedToday ? (
              <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Uploaded today! Streak maintained.
              </span>
            ) : (
              'Pending today — publish content to keep your streak alive!'
            )}
          </p>
        </div>

        {/* Best Streak */}
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Best Streak
            </span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Award className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-4xl sm:text-5xl font-black text-slate-900 dark:text-white tabular-nums">
              {bestStreak}
            </span>
            <span className="text-base sm:text-lg font-bold text-indigo-600 dark:text-indigo-400">
              Days record
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
            Your all-time highest daily upload record
          </p>
        </div>

        {/* Total Uploads */}
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Total Uploads
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <BarChart3 className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-4xl sm:text-5xl font-black text-slate-900 dark:text-white tabular-nums">
              {totalUploads}
            </span>
            <span className="text-base sm:text-lg font-bold text-emerald-600 dark:text-emerald-400">
              Videos
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
            Total videos logged across all platforms
          </p>
        </div>
      </div>

      {/* 2. Weekly Uploads Visual Bar Chart */}
      <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-sm">
        <div className="flex items-center justify-between mb-6 flex-wrap gap-2">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-rose-500" />
              <span>Weekly Upload Chart (Past 7 Days)</span>
            </h3>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Frequency of completed uploads by day
            </span>
          </div>

          <button
            type="button"
            onClick={() => setShowManualForm(!showManualForm)}
            className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 hover:bg-rose-100 border border-rose-200/60 dark:border-rose-800/40 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Log Upload</span>
          </button>
        </div>

        {/* Quick Manual Upload Form */}
        {showManualForm && (
          <form
            onSubmit={handleQuickUploadSubmit}
            className="mb-6 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 animate-in fade-in duration-150"
          >
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block mb-2">
              Log an upload manually (maintains your streak without an alarm):
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <select
                value={selectedPlatformId}
                onChange={(e) => setSelectedPlatformId(e.target.value)}
                className="px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-rose-500"
              >
                {platforms.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>

              <input
                type="text"
                placeholder="Note (e.g. Uploaded evening Reel)"
                value={customNote}
                onChange={(e) => setCustomNote(e.target.value)}
                className="px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-400 focus:ring-2 focus:ring-rose-500"
              />

              <button
                type="submit"
                className="min-h-[38px] px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Save & Count Streak</span>
              </button>
            </div>
          </form>
        )}

        {/* 7-Day Bar Columns */}
        <div className="grid grid-cols-7 gap-2 sm:gap-4 items-end pt-8 pb-3 border-b border-slate-100 dark:border-slate-800 min-h-[190px]">
          {past7Days.map((day) => {
            const heightPercent = day.count === 0 ? 8 : Math.min(100, (day.count / maxDayCount) * 100);
            return (
              <div key={day.dateKey} className="flex flex-col items-center gap-2 h-full justify-end group">
                {/* Count Badge on Hover or If > 0 */}
                <span
                  className={`text-xs font-bold tabular-nums transition-opacity ${
                    day.count > 0 ? 'text-slate-900 dark:text-white' : 'text-slate-400'
                  }`}
                >
                  {day.count}
                </span>

                {/* Animated Bar Column */}
                <div className="w-full max-w-[38px] bg-slate-100 dark:bg-slate-800 rounded-lg flex flex-col justify-end overflow-hidden h-32 p-0.5">
                  <div
                    style={{ height: `${heightPercent}%` }}
                    className={`w-full rounded-md transition-all duration-500 ${
                      day.isToday
                        ? 'bg-rose-500 shadow-md shadow-rose-500/20'
                        : day.count > 0
                        ? 'bg-indigo-500 dark:bg-indigo-600'
                        : 'bg-slate-200 dark:bg-slate-700/60'
                    }`}
                  />
                </div>

                {/* Day Name & Date */}
                <div className="text-center">
                  <span
                    className={`text-xs block font-bold ${
                      day.isToday
                        ? 'text-rose-600 dark:text-rose-400'
                        : 'text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {day.dayName}
                  </span>
                  <span className="text-[10px] text-slate-400 tabular-nums">
                    {day.dateNum}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. Platform Distribution Breakdown */}
      <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-sm">
        <h3 className="text-base font-bold text-slate-900 dark:text-white mb-4">
          Total Uploads by Platform
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {platformCounts.map(({ platform, count }) => (
            <div
              key={platform.id}
              className="p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-white shrink-0"
                  style={{ backgroundColor: platform.color }}
                >
                  <PlatformIcon iconName={platform.iconName} className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block truncate">
                    {platform.name}
                  </span>
                </div>
              </div>

              <span className="text-sm font-extrabold text-slate-900 dark:text-white tabular-nums shrink-0">
                {count}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* 4. Recent Upload Activity History */}
      <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-slate-500" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Recent Upload Activity Log
            </h3>
          </div>
          {uploads.length > 0 && onClearHistory && (
            <button
              type="button"
              onClick={onClearHistory}
              className="text-xs text-rose-600 dark:text-rose-400 hover:underline cursor-pointer"
            >
              Clear History
            </button>
          )}
        </div>

        {uploads.length === 0 ? (
          <div className="py-8 text-center text-slate-500 dark:text-slate-400 text-xs">
            No uploads logged yet.
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-72 overflow-y-auto">
            {uploads.slice(0, 10).map((record) => {
              const platform = platforms.find((p) => p.id === record.platformId);
              const dateObj = new Date(record.timestamp);
              const formattedDate = dateObj.toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                year: 'numeric',
              });
              const formattedTime = dateObj.toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit',
              });

              return (
                <div
                  key={record.id}
                  className="py-3 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center text-white shrink-0"
                      style={{ backgroundColor: platform?.color || '#64748B' }}
                    >
                      <PlatformIcon
                        iconName={platform?.iconName || 'globe'}
                        className="w-3.5 h-3.5"
                      />
                    </div>
                    <div className="min-w-0">
                      <span className="font-bold text-slate-800 dark:text-slate-200 block truncate">
                        {record.platformName}
                      </span>
                      {record.note && (
                        <span className="text-[11px] text-slate-500 dark:text-slate-400 block truncate">
                          {record.note}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="text-right shrink-0 text-slate-500 dark:text-slate-400">
                    <span className="block font-medium">{formattedDate}</span>
                    <span className="block text-[10px] tabular-nums">{formattedTime}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
