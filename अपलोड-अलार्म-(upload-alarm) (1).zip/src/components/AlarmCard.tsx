import React from 'react';
import { Alarm, Platform } from '../types';
import { PlatformIcon } from './PlatformIcon';
import { formatTimeShort, getTimePeriodLabel, formatRepeatDaysEnglish, getTimeUntilNextAlarm } from '../utils/timeUtils';
import { Bell, Edit3, Trash2, Play } from 'lucide-react';

interface AlarmCardProps {
  alarm: Alarm;
  platform: Platform;
  onToggle: (id: string) => void;
  onEdit: (alarm: Alarm) => void;
  onDelete: (id: string) => void;
  onTest: (alarm: Alarm) => void;
}

export const AlarmCard: React.FC<AlarmCardProps> = ({
  alarm,
  platform,
  onToggle,
  onEdit,
  onDelete,
  onTest,
}) => {
  const timeCountdown = alarm.enabled ? getTimeUntilNextAlarm(alarm.time, alarm.repeatDays) : '';
  const periodLabel = getTimePeriodLabel(alarm.time);

  return (
    <div
      className={`group relative rounded-2xl border transition-all p-4 sm:p-5 ${
        alarm.enabled
          ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md'
          : 'bg-slate-50/80 dark:bg-slate-900/40 border-slate-200/60 dark:border-slate-800/60 opacity-75'
      }`}
    >
      <div className="flex items-start justify-between gap-4">
        {/* Left: Platform Icon & Time */}
        <div className="flex items-start gap-3.5 min-w-0">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 shadow-sm transition-transform group-hover:scale-105"
            style={{ backgroundColor: platform.color }}
          >
            <PlatformIcon iconName={platform.iconName} className="w-6 h-6 text-white" />
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-bold text-sm text-slate-800 dark:text-slate-100">
                {platform.name}
              </span>
            </div>

            {/* Time display with AM/PM and period (Morning, Afternoon, Evening, Night) */}
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white tabular-nums">
                {formatTimeShort(alarm.time)}
              </span>
              <span className="text-xs sm:text-sm font-semibold text-rose-600 dark:text-rose-400">
                · {periodLabel}
              </span>
            </div>

            {/* Repeat Days */}
            <p className="text-xs font-medium text-slate-600 dark:text-slate-400 mt-1">
              {formatRepeatDaysEnglish(alarm.repeatDays)}
            </p>
          </div>
        </div>

        {/* Right: Toggle Switch (Min 44x44px touch area) */}
        <div className="flex items-center shrink-0">
          <label className="relative inline-flex items-center cursor-pointer p-2 -mr-2">
            <input
              type="checkbox"
              checked={alarm.enabled}
              onChange={() => onToggle(alarm.id)}
              className="sr-only peer"
              aria-label={`Toggle ${platform.name} alarm`}
            />
            <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[10px] after:left-[10px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-600 peer-checked:bg-rose-500"></div>
          </label>
        </div>
      </div>

      {/* Note or Instruction */}
      {alarm.note && (
        <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800/80">
          <p className="text-xs text-slate-700 dark:text-slate-300 line-clamp-2">
            <span className="font-semibold text-slate-900 dark:text-slate-100">Note:</span> {alarm.note}
          </p>
        </div>
      )}

      {/* Card Footer with Countdown & Quick Actions */}
      <div className="mt-3.5 pt-2.5 flex items-center justify-between border-t border-slate-100 dark:border-slate-800/60 text-xs">
        <div>
          {alarm.enabled && timeCountdown ? (
            <span className="inline-flex items-center gap-1 font-medium text-emerald-600 dark:text-emerald-400">
              <Bell className="w-3.5 h-3.5" />
              <span>{timeCountdown}</span>
            </span>
          ) : (
            <span className="text-slate-500 dark:text-slate-400">Alarm is off</span>
          )}
        </div>

        <div className="flex items-center gap-1">
          {/* Test Ring Button */}
          <button
            type="button"
            onClick={() => onTest(alarm)}
            title="Test Alarm Sound & Alert"
            className="min-h-[40px] px-2.5 py-1.5 rounded-lg text-slate-600 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 font-medium flex items-center gap-1 transition-colors cursor-pointer"
          >
            <Play className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Test</span>
          </button>

          {/* Edit Button */}
          <button
            type="button"
            onClick={() => onEdit(alarm)}
            title="Edit Alarm"
            className="min-h-[40px] min-w-[40px] p-2 rounded-lg text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition-colors cursor-pointer"
          >
            <Edit3 className="w-4 h-4" />
          </button>

          {/* Delete Button */}
          <button
            type="button"
            onClick={() => onDelete(alarm.id)}
            title="Delete Alarm"
            className="min-h-[40px] min-w-[40px] p-2 rounded-lg text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center justify-center transition-colors cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
