import React from 'react';
import { Bell, X } from 'lucide-react';

interface NotificationBannerProps {
  onAllow: () => void;
  onDismiss: () => void;
}

export const NotificationBanner: React.FC<NotificationBannerProps> = ({
  onAllow,
  onDismiss,
}) => {
  return (
    <aside
      aria-label="Notification Permission Request"
      className="rounded-2xl bg-gradient-to-r from-amber-50 to-rose-50 dark:from-amber-950/40 dark:to-rose-950/30 border border-amber-200/80 dark:border-amber-800/40 p-4 shadow-sm mb-6 flex items-center justify-between gap-4 flex-wrap sm:flex-nowrap"
    >
      <div className="flex items-center gap-3 min-w-0">
        <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-sm">
          <Bell className="w-5 h-5 animate-bounce" />
        </div>
        <div className="min-w-0">
          <h2 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white block">
            Enable notifications for timely upload reminders
          </h2>
          <p className="text-[11px] sm:text-xs text-slate-600 dark:text-slate-300">
            Receive reminders right on time even if you are browsing in another tab or application.
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
        <button
          type="button"
          onClick={onDismiss}
          className="min-h-[40px] px-3 py-1.5 text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
        >
          Later
        </button>

        <button
          type="button"
          onClick={onAllow}
          className="min-h-[40px] px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 active:scale-95 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
        >
          <Bell className="w-3.5 h-3.5" />
          <span>Allow</span>
        </button>
        <button
          type="button"
          onClick={onDismiss}
          className="w-8 h-8 rounded-lg hover:bg-black/5 dark:hover:bg-white/10 text-slate-400 flex items-center justify-center cursor-pointer"
          aria-label="Dismiss banner"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );
};
