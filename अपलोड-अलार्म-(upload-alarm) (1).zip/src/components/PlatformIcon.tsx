import React from 'react';
import {
  Youtube,
  Instagram,
  Facebook,
  Music2,
  Twitter,
  Linkedin,
  Share2,
  Globe,
  Video,
  Camera,
} from 'lucide-react';

interface PlatformIconProps {
  iconName: string;
  className?: string;
}

export const PlatformIcon: React.FC<PlatformIconProps> = ({ iconName, className = 'w-5 h-5' }) => {
  switch (iconName.toLowerCase()) {
    case 'youtube':
      return <Youtube className={className} />;
    case 'instagram':
      return <Instagram className={className} />;
    case 'facebook':
      return <Facebook className={className} />;
    case 'tiktok':
      return <Music2 className={className} />;
    case 'twitter':
    case 'x':
      return <Twitter className={className} />;
    case 'linkedin':
      return <Linkedin className={className} />;
    case 'sharechat':
      return <Share2 className={className} />;
    case 'video':
      return <Video className={className} />;
    case 'camera':
      return <Camera className={className} />;
    default:
      return <Globe className={className} />;
  }
};
