import React, { useState } from 'react';
import { Alarm, Platform } from '../types';
import { AlarmCard } from './AlarmCard';
import { getTimeUntilNextAlarm, formatTimeShort, getTimePeriodLabel } from '../utils/timeUtils';
import { Plus, Bell, Play, Sparkles } from 'lucide-react';

interface AlarmListProps {
  alarms: Alarm[];
  platforms: Platform[];
  onToggleAlarm: (id: string) => void;
  onEditAlarm: (alarm: Alarm) => void;
  onDeleteAlarm: (id: string) => void;
  onCreateAlarm: () => void;
  onTestAlarm: (alarm: Alarm) => void;
}

export const AlarmList: React.FC<AlarmListProps> = ({
  alarms,
  platforms,
  onToggleAlarm,
  onEditAlarm,
  onDeleteAlarm,
  onCreateAlarm,
  onTestAlarm,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'enabled' | 'disabled'>('all');
  const [selectedPlatformFilter, setSelectedPlatformFilter] = useState<string>('all');

  // Sort chronologically by time "HH:mm"
  const sortedAlarms = [...alarms].sort((a, b) => a.time.localeCompare(b.time));

  // Filter based on active tab and platform
  const filteredAlarms = sortedAlarms.filter((a) => {
    if (activeTab === 'enabled' && !a.enabled) return false;
    if (activeTab === 'disabled' && a.enabled) return false;
    if (selectedPlatformFilter !== 'all' && a.platformId !== selectedPlatformFilter) return false;
    return true;
  });

  // Find the next upcoming enabled alarm
  const nextAlarmInfo = (() => {
    const enabledAlarms = sortedAlarms.filter((a) => a.enabled);
    if (enabledAlarms.length === 0) return null;

    // Pick first alarm that has a countdown string
    for (const alarm of enabledAlarms) {
      const countdown = getTimeUntilNextAlarm(alarm.time, alarm.repeatDays);
      if (countdown) {
        const platform = platforms.find((p) => p.id === alarm.platformId);
        return {
          alarm,
          platform,
          countdown,
        };
      }
    }
    return null;
  })();

  return (
    <div className="space-y-6">
      {/* 1. Next Upcoming Alarm Highlight Banner */}
      {nextAlarmInfo && (
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-rose-500 to-rose-600 dark:from-rose-600 dark:to-rose-800 text-white p-5 shadow-lg shadow-rose-500/15">
          <div className="relative z-10 flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center shrink-0">
                <Bell className="w-6 h-6 text-white animate-pulse" />
              </div>
              <div>
                <span className="text-xs uppercase font-bold tracking-wider text-white/80 block">
                  Next Upcoming Alarm
                </span>
                <div className="flex items-baseline gap-2 mt-0.5">
                  <h3 className="text-xl sm:text-2xl font-black">
                    {nextAlarmInfo.platform?.name} · {formatTimeShort(nextAlarmInfo.alarm.time)}
                  </h3>
                  <span className="text-xs font-semibold text-rose-100">
                    ({getTimePeriodLabel(nextAlarmInfo.alarm.time)})
                  </span>
                </div>
                <p className="text-xs text-rose-100 mt-1">
                  Time remaining: <strong className="text-white">{nextAlarmInfo.countdown}</strong>
                  {nextAlarmInfo.alarm.note && ` — "${nextAlarmInfo.alarm.note}"`}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onTestAlarm(nextAlarmInfo.alarm)}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-white text-rose-700 hover:bg-rose-50 active:scale-95 font-bold text-xs flex items-center gap-2 shadow-sm transition-all cursor-pointer"
            >
              <Play className="w-4 h-4 fill-rose-600" />
              <span>Test Alert</span>
            </button>
          </div>
        </div>
      )}

      {/* 2. Controls Bar: Tabs, Filters, Add Button */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Interactive Segmented Filter Control */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              activeTab === 'all'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            All ({alarms.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('enabled')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              activeTab === 'enabled'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Active ({alarms.filter((a) => a.enabled).length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('disabled')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              activeTab === 'disabled'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Inactive ({alarms.filter((a) => !a.enabled).length})
          </button>
        </div>

        {/* Platform Filter Dropdown & Primary Add Button */}
        <div className="flex items-center gap-2">
          <select
            value={selectedPlatformFilter}
            onChange={(e) => setSelectedPlatformFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-rose-500 cursor-pointer"
          >
            <option value="all">All Platforms</option>
            {platforms.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={onCreateAlarm}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-rose-600/20 active:scale-95 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>New Alarm</span>
          </button>
        </div>
      </div>

      {/* 3. Alarm Cards Grid (sorted chronologically) */}
      {filteredAlarms.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 p-8 sm:p-12 text-center bg-white/40 dark:bg-slate-900/40">
          <div className="w-14 h-14 rounded-2xl bg-rose-50 dark:bg-rose-950/40 text-rose-500 mx-auto flex items-center justify-center mb-4">
            <Bell className="w-7 h-7" />
          </div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">
            No Alarms Found
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-sm mx-auto mb-6">
            {activeTab !== 'all' || selectedPlatformFilter !== 'all'
              ? 'No alarms match your current filter selection. Try resetting filters.'
              : 'Create an alarm to get timely reminders for uploading content across your social platforms.'}
          </p>
          <button
            type="button"
            onClick={onCreateAlarm}
            className="min-h-[44px] px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm inline-flex items-center gap-2 shadow-md shadow-rose-600/20 cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>Create First Alarm</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredAlarms.map((alarm) => {
            const platform =
              platforms.find((p) => p.id === alarm.platformId) || platforms[0];
            return (
              <AlarmCard
                key={alarm.id}
                alarm={alarm}
                platform={platform}
                onToggle={onToggleAlarm}
                onEdit={onEditAlarm}
                onDelete={onDeleteAlarm}
                onTest={onTestAlarm}
              />
            );
          })}
        </div>
      )}
    </div>
  );
};
