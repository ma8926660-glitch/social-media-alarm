import { Platform, Alarm, UploadRecord, AppSettings } from '../types';

export const DEFAULT_PLATFORMS: Platform[] = [
  {
    id: 'youtube',
    name: 'YouTube',
    nameEn: 'YouTube',
    color: '#FF0000',
    bgColor: 'bg-red-500',
    textColor: 'text-white',
    iconName: 'youtube',
  },
  {
    id: 'instagram',
    name: 'Instagram',
    nameEn: 'Instagram',
    color: '#E1306C',
    bgColor: 'bg-pink-600',
    textColor: 'text-white',
    iconName: 'instagram',
  },
  {
    id: 'facebook',
    name: 'Facebook',
    nameEn: 'Facebook',
    color: '#1877F2',
    bgColor: 'bg-blue-600',
    textColor: 'text-white',
    iconName: 'facebook',
  },
  {
    id: 'tiktok',
    name: 'TikTok',
    nameEn: 'TikTok',
    color: '#111827',
    bgColor: 'bg-slate-900',
    textColor: 'text-white',
    iconName: 'tiktok',
  },
  {
    id: 'twitter',
    name: 'X (Twitter)',
    nameEn: 'X / Twitter',
    color: '#0F1419',
    bgColor: 'bg-zinc-800',
    textColor: 'text-white',
    iconName: 'twitter',
  },
  {
    id: 'linkedin',
    name: 'LinkedIn',
    nameEn: 'LinkedIn',
    color: '#0A66C2',
    bgColor: 'bg-sky-700',
    textColor: 'text-white',
    iconName: 'linkedin',
  },
  {
    id: 'sharechat',
    name: 'ShareChat',
    nameEn: 'ShareChat',
    color: '#FF7A00',
    bgColor: 'bg-orange-500',
    textColor: 'text-white',
    iconName: 'sharechat',
  },
];

const STORAGE_KEYS = {
  PLATFORMS: 'social_media_alarm_platforms_v2',
  ALARMS: 'social_media_alarm_alarms_v2',
  UPLOADS: 'social_media_alarm_uploads_v2',
  SETTINGS: 'social_media_alarm_settings_v2',
  NOTIF_DISMISSED: 'social_media_alarm_notif_banner_dismissed_v2',
};

// Formats a Date object to "YYYY-MM-DD"
export function formatDateKey(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getInitialAlarms(): Alarm[] {
  return [
    {
      id: 'alarm_1',
      platformId: 'youtube',
      time: '10:00',
      repeatDays: [], // Daily
      note: 'Upload new tech video and Shorts',
      enabled: true,
      soundType: 'energy',
      createdAt: Date.now() - 86400000 * 3,
    },
    {
      id: 'alarm_2',
      platformId: 'instagram',
      time: '18:30',
      repeatDays: [1, 2, 3, 4, 5], // Mon to Fri
      note: 'Post evening trending Reel',
      enabled: true,
      soundType: 'digital',
      createdAt: Date.now() - 86400000 * 2,
    },
    {
      id: 'alarm_3',
      platformId: 'facebook',
      time: '20:15',
      repeatDays: [0, 6], // Sun & Sat
      note: 'Weekend special video & community post',
      enabled: true,
      soundType: 'chime',
      createdAt: Date.now() - 86400000,
    },
  ];
}

export function getInitialUploads(): UploadRecord[] {
  const now = new Date();
  const records: UploadRecord[] = [];

  // Create 4 days of history leading up to today so streak is visually active and motivating
  for (let i = 3; i >= 1; i--) {
    const d = new Date(now.getTime() - i * 86400000);
    const dateStr = formatDateKey(d);
    records.push({
      id: `seed_${i}_1`,
      platformId: i % 2 === 0 ? 'youtube' : 'instagram',
      platformName: i % 2 === 0 ? 'YouTube' : 'Instagram',
      timestamp: d.getTime(),
      dateString: dateStr,
      note: 'Successfully uploaded video',
    });
  }
  return records;
}

export const storageService = {
  getPlatforms(): Platform[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PLATFORMS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.PLATFORMS, JSON.stringify(DEFAULT_PLATFORMS));
        return DEFAULT_PLATFORMS;
      }
      const parsed: Platform[] = JSON.parse(data);
      // Ensure default platforms show English names
      const englishUpdated = parsed.map((p) => {
        const def = DEFAULT_PLATFORMS.find((dp) => dp.id === p.id);
        if (def && !p.isCustom) {
          return { ...p, name: def.name, nameEn: def.nameEn };
        }
        return p;
      });
      return englishUpdated;
    } catch {
      return DEFAULT_PLATFORMS;
    }
  },

  savePlatforms(platforms: Platform[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.PLATFORMS, JSON.stringify(platforms));
    } catch (e) {
      console.error(e);
    }
  },

  getAlarms(): Alarm[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ALARMS);
      if (!data) {
        const initial = getInitialAlarms();
        localStorage.setItem(STORAGE_KEYS.ALARMS, JSON.stringify(initial));
        return initial;
      }
      return JSON.parse(data);
    } catch {
      return [];
    }
  },

  saveAlarms(alarms: Alarm[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.ALARMS, JSON.stringify(alarms));
    } catch (e) {
      console.error(e);
    }
  },

  getUploads(): UploadRecord[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.UPLOADS);
      if (!data) {
        const initial = getInitialUploads();
        localStorage.setItem(STORAGE_KEYS.UPLOADS, JSON.stringify(initial));
        return initial;
      }
      return JSON.parse(data);
    } catch {
      return [];
    }
  },

  saveUploads(uploads: UploadRecord[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.UPLOADS, JSON.stringify(uploads));
    } catch (e) {
      console.error(e);
    }
  },

  addUpload(platformId: string, platformName: string, note?: string): UploadRecord {
    const uploads = this.getUploads();
    const now = new Date();
    const newRecord: UploadRecord = {
      id: 'upload_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      platformId,
      platformName,
      timestamp: now.getTime(),
      dateString: formatDateKey(now),
      note: note || 'Upload completed',
    };
    uploads.unshift(newRecord);
    this.saveUploads(uploads);
    return newRecord;
  },

  getSettings(): AppSettings {
    const defaultSettings: AppSettings = {
      soundEnabled: true,
      soundType: 'energy',
      volume: 0.85,
      vibrationEnabled: true,
      darkMode: false,
    };
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (!data) return defaultSettings;
      return { ...defaultSettings, ...JSON.parse(data) };
    } catch {
      return defaultSettings;
    }
  },

  saveSettings(settings: AppSettings) {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.error(e);
    }
  },

  resetAllData() {
    localStorage.removeItem(STORAGE_KEYS.PLATFORMS);
    localStorage.removeItem(STORAGE_KEYS.ALARMS);
    localStorage.removeItem(STORAGE_KEYS.UPLOADS);
    localStorage.removeItem(STORAGE_KEYS.SETTINGS);
    // Also clear old v1 keys if present
    localStorage.removeItem('upload_alarm_platforms_v1');
    localStorage.removeItem('upload_alarm_alarms_v1');
    localStorage.removeItem('upload_alarm_uploads_v1');
    localStorage.removeItem('upload_alarm_settings_v1');
  },
};

/**
 * Calculates current streak (consecutive calendar days with at least 1 upload)
 * Best streak across all time, and total count.
 */
export function calculateStreaks(uploads: UploadRecord[]): {
  currentStreak: number;
  bestStreak: number;
  totalUploads: number;
  uploadedToday: boolean;
} {
  if (!uploads || uploads.length === 0) {
    return { currentStreak: 0, bestStreak: 0, totalUploads: 0, uploadedToday: false };
  }

  // Set of unique dates "YYYY-MM-DD"
  const dateSet = new Set(uploads.map((u) => u.dateString));
  const today = new Date();
  const todayKey = formatDateKey(today);
  const uploadedToday = dateSet.has(todayKey);

  // Check backwards from today (or yesterday if not uploaded today yet)
  let checkDate = new Date(today);
  if (!uploadedToday) {
    checkDate.setDate(checkDate.getDate() - 1);
  }

  let currentStreak = 0;
  while (dateSet.has(formatDateKey(checkDate))) {
    currentStreak++;
    checkDate.setDate(checkDate.getDate() - 1);
  }

  // Calculate best streak historically
  const sortedDates = Array.from(dateSet).sort();
  let bestStreak = 0;
  let tempStreak = 0;
  let lastDate: Date | null = null;

  for (const dStr of sortedDates) {
    const [y, m, d] = dStr.split('-').map(Number);
    const currentDate = new Date(y, m - 1, d);

    if (lastDate) {
      const diffTime = currentDate.getTime() - lastDate.getTime();
      const diffDays = Math.round(diffTime / (1000 * 3600 * 24));
      if (diffDays === 1) {
        tempStreak++;
      } else if (diffDays > 1) {
        tempStreak = 1;
      }
    } else {
      tempStreak = 1;
    }
    if (tempStreak > bestStreak) bestStreak = tempStreak;
    lastDate = currentDate;
  }

  return {
    currentStreak,
    bestStreak: Math.max(bestStreak, currentStreak),
    totalUploads: uploads.length,
    uploadedToday,
  };
}
