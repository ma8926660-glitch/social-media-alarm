import { SoundType } from '../types';

class AudioService {
  private ctx: AudioContext | null = null;
  private isLooping = false;
  private loopTimer: number | null = null;
  private masterGain: GainNode | null = null;
  private currentVolume = 0.8;

  private initContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {
        // Ignored; will resume upon next gesture
      });
    }
    return this.ctx;
  }

  public setVolume(vol: number) {
    this.currentVolume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.currentVolume, this.ctx.currentTime);
    }
  }

  public getVolume(): number {
    return this.currentVolume;
  }

  // Pre-unlock audio context on any user tap/click
  public unlockAudio() {
    try {
      const ctx = this.initContext();
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
    } catch {
      // ignore
    }
  }

  private playTonePattern(type: SoundType) {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;

    const gainNode = this.ctx.createGain();
    gainNode.gain.setValueAtTime(this.currentVolume, now);
    gainNode.connect(this.ctx.destination);
    this.masterGain = gainNode;

    switch (type) {
      case 'digital': {
        // High-pitched double beep: 880Hz then 1760Hz
        const osc1 = this.ctx.createOscillator();
        const oscGain1 = this.ctx.createGain();
        osc1.type = 'square';
        osc1.frequency.setValueAtTime(880, now);
        osc1.frequency.setValueAtTime(1760, now + 0.12);
        oscGain1.gain.setValueAtTime(0.3, now);
        oscGain1.gain.exponentialRampToValueAtTime(0.01, now + 0.28);
        osc1.connect(oscGain1);
        oscGain1.connect(gainNode);
        osc1.start(now);
        osc1.stop(now + 0.3);

        const osc2 = this.ctx.createOscillator();
        const oscGain2 = this.ctx.createGain();
        osc2.type = 'square';
        osc2.frequency.setValueAtTime(880, now + 0.35);
        osc2.frequency.setValueAtTime(1760, now + 0.47);
        oscGain2.gain.setValueAtTime(0.3, now + 0.35);
        oscGain2.gain.exponentialRampToValueAtTime(0.01, now + 0.63);
        osc2.connect(oscGain2);
        oscGain2.connect(gainNode);
        osc2.start(now + 0.35);
        osc2.stop(now + 0.65);
        break;
      }

      case 'energy': {
        // Ascending motivational notes: C5 (523Hz), E5 (659Hz), G5 (784Hz), C6 (1046Hz)
        const notes = [523.25, 659.25, 783.99, 1046.5];
        notes.forEach((freq, i) => {
          if (!this.ctx) return;
          const osc = this.ctx.createOscillator();
          const noteGain = this.ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, now + i * 0.12);
          noteGain.gain.setValueAtTime(0.4, now + i * 0.12);
          noteGain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.12 + 0.2);
          osc.connect(noteGain);
          noteGain.connect(gainNode);
          osc.start(now + i * 0.12);
          osc.stop(now + i * 0.12 + 0.22);
        });
        break;
      }

      case 'chime': {
        // Melodic resonant bell harmonic chime
        const freqs = [659.25, 987.77, 1318.51];
        freqs.forEach((freq, idx) => {
          if (!this.ctx) return;
          const osc = this.ctx.createOscillator();
          const noteGain = this.ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now + idx * 0.15);
          noteGain.gain.setValueAtTime(0.35, now + idx * 0.15);
          noteGain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.15 + 0.7);
          osc.connect(noteGain);
          noteGain.connect(gainNode);
          osc.start(now + idx * 0.15);
          osc.stop(now + idx * 0.15 + 0.75);
        });
        break;
      }

      case 'radar': {
        // Frequency sweep radar ping
        const osc = this.ctx.createOscillator();
        const noteGain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(400, now);
        osc.frequency.exponentialRampToValueAtTime(1400, now + 0.4);
        noteGain.gain.setValueAtTime(0.35, now);
        noteGain.gain.exponentialRampToValueAtTime(0.01, now + 0.45);
        osc.connect(noteGain);
        noteGain.connect(gainNode);
        osc.start(now);
        osc.stop(now + 0.5);

        const oscSub = this.ctx.createOscillator();
        const subGain = this.ctx.createGain();
        oscSub.type = 'triangle';
        oscSub.frequency.setValueAtTime(800, now + 0.2);
        oscSub.frequency.exponentialRampToValueAtTime(1600, now + 0.55);
        subGain.gain.setValueAtTime(0.2, now + 0.2);
        subGain.gain.exponentialRampToValueAtTime(0.01, now + 0.6);
        oscSub.connect(subGain);
        subGain.connect(gainNode);
        oscSub.start(now + 0.2);
        oscSub.stop(now + 0.6);
        break;
      }
    }
  }

  // Play a single preview cycle
  public playPreview(type: SoundType) {
    this.stopAlarm();
    this.initContext();
    this.playTonePattern(type);
  }

  // Start continuous looping alarm
  public startAlarmLoop(type: SoundType) {
    this.stopAlarm();
    this.initContext();
    this.isLooping = true;

    // Immediately play first pulse
    this.playTonePattern(type);

    // Loop interval based on sound type
    const intervalMs = type === 'chime' ? 1400 : 1100;
    this.loopTimer = window.setInterval(() => {
      if (this.isLooping) {
        this.playTonePattern(type);
      }
    }, intervalMs);
  }

  public stopAlarm() {
    this.isLooping = false;
    if (this.loopTimer !== null) {
      clearInterval(this.loopTimer);
      this.loopTimer = null;
    }
  }

  public isAlarmPlaying(): boolean {
    return this.isLooping;
  }
}

export const audioService = new AudioService();
