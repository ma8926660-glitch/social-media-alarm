import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';

class NotificationService {
  private vibrateInterval: number | null = null;
  private notificationCounter = 1;

  public isSupported(): boolean {
    if (Capacitor.isNativePlatform()) {
      return true;
    }
    return 'Notification' in window;
  }

  public getPermissionStatus(): NotificationPermission | 'unsupported' {
    if (Capacitor.isNativePlatform()) {
      return 'granted';
    }
    if (!this.isSupported()) return 'unsupported';
    return Notification.permission;
  }

  public async requestPermission(): Promise<boolean> {
    if (Capacitor.isNativePlatform()) {
      try {
        const res = await LocalNotifications.requestPermissions();
        return res.display === 'granted';
      } catch {
        return false;
      }
    }

    if (!this.isSupported()) return false;
    try {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    } catch {
      return false;
    }
  }

  public sendNotification(title: string, options?: NotificationOptions): boolean {
    if (Capacitor.isNativePlatform()) {
      try {
        LocalNotifications.schedule({
          notifications: [
            {
              title,
              body: options?.body || 'Time to upload your content!',
              id: this.notificationCounter++,
              schedule: { at: new Date(Date.now() + 100) },
              sound: undefined,
              actionTypeId: '',
              extra: null,
            },
          ],
        });
        return true;
      } catch {
        return false;
      }
    }

    if (!this.isSupported() || Notification.permission !== 'granted') {
      return false;
    }

    try {
      const opts: NotificationOptions & { renotify?: boolean; requireInteraction?: boolean } = {
        icon: '/favicon.ico',
        badge: '/favicon.ico',
        renotify: true,
        tag: 'social-media-alarm',
        requireInteraction: true,
        ...options,
      };
      const notif = new Notification(title, opts);

      notif.onclick = () => {
        window.focus();
        notif.close();
      };

      return true;
    } catch {
      return false;
    }
  }

  public startVibration(pattern: number[] = [400, 200, 400, 200, 600]) {
    this.stopVibration();
    if ('vibrate' in navigator) {
      try {
        navigator.vibrate(pattern);
        this.vibrateInterval = window.setInterval(() => {
          navigator.vibrate(pattern);
        }, 2000);
      } catch {
        // Ignore on unsupported mobile browsers
      }
    }
  }

  public stopVibration() {
    if (this.vibrateInterval !== null) {
      clearInterval(this.vibrateInterval);
      this.vibrateInterval = null;
    }
    if ('vibrate' in navigator) {
      try {
        navigator.vibrate(0);
      } catch {
        // Ignore
      }
    }
  }
}

export const notificationService = new NotificationService();
