export const DAYS_OF_WEEK = [
  { index: 0, short: 'Sun', full: 'Sunday' },
  { index: 1, short: 'Mon', full: 'Monday' },
  { index: 2, short: 'Tue', full: 'Tuesday' },
  { index: 3, short: 'Wed', full: 'Wednesday' },
  { index: 4, short: 'Thu', full: 'Thursday' },
  { index: 5, short: 'Fri', full: 'Friday' },
  { index: 6, short: 'Sat', full: 'Saturday' },
];

// For backward compatibility
export const HINDI_DAYS = DAYS_OF_WEEK;

export function formatTimeEnglish(time24: string): string {
  if (!time24 || !time24.includes(':')) return time24;
  const [hStr, mStr] = time24.split(':');
  let h = parseInt(hStr, 10);
  const m = parseInt(mStr, 10);
  const mFormatted = String(m).padStart(2, '0');

  let period = '';
  let ampm = 'AM';

  if (h === 0) {
    period = 'Night';
    ampm = 'AM';
    h = 12;
  } else if (h < 5) {
    period = 'Late Night';
    ampm = 'AM';
  } else if (h < 12) {
    period = 'Morning';
    ampm = 'AM';
  } else if (h === 12) {
    period = 'Afternoon';
    ampm = 'PM';
  } else if (h < 17) {
    period = 'Afternoon';
    ampm = 'PM';
    h = h - 12;
  } else if (h < 21) {
    period = 'Evening';
    ampm = 'PM';
    h = h - 12;
  } else {
    period = 'Night';
    ampm = 'PM';
    h = h - 12;
  }

  const hFormatted = String(h).padStart(2, '0');
  return `${hFormatted}:${mFormatted} ${ampm} (${period})`;
}

export function formatTimeShort(time24: string): string {
  if (!time24 || !time24.includes(':')) return time24;
  const [hStr, mStr] = time24.split(':');
  let h = parseInt(hStr, 10);
  const m = parseInt(mStr, 10);
  const mFormatted = String(m).padStart(2, '0');
  const ampm = h >= 12 ? 'PM' : 'AM';
  if (h === 0) h = 12;
  else if (h > 12) h -= 12;
  const hFormatted = String(h).padStart(2, '0');
  return `${hFormatted}:${mFormatted} ${ampm}`;
}

export function getTimePeriodLabel(time24: string): string {
  if (!time24 || !time24.includes(':')) return '';
  const h = parseInt(time24.split(':')[0], 10);
  if (h < 5) return 'Late Night';
  if (h < 12) return 'Morning';
  if (h < 17) return 'Afternoon';
  if (h < 21) return 'Evening';
  return 'Night';
}

export function formatRepeatDaysEnglish(days: number[]): string {
  if (!days || days.length === 0 || days.length === 7) {
    return 'Daily (Every day)';
  }
  if (days.length === 5 && [1, 2, 3, 4, 5].every((d) => days.includes(d))) {
    return 'Weekdays (Mon - Fri)';
  }
  if (days.length === 2 && days.includes(0) && days.includes(6)) {
    return 'Weekends (Sat, Sun)';
  }

  return days
    .slice()
    .sort((a, b) => a - b)
    .map((d) => DAYS_OF_WEEK[d]?.short || '')
    .filter(Boolean)
    .join(', ');
}

export function getTimeUntilNextAlarm(alarmTime: string, repeatDays: number[]): string {
  const [alarmH, alarmM] = alarmTime.split(':').map(Number);
  const now = new Date();

  // Look ahead up to 7 days
  for (let offset = 0; offset < 8; offset++) {
    const candidate = new Date(now);
    candidate.setDate(now.getDate() + offset);
    candidate.setHours(alarmH, alarmM, 0, 0);

    const dayOfWeek = candidate.getDay();
    const isDayAllowed = repeatDays.length === 0 || repeatDays.includes(dayOfWeek);

    if (isDayAllowed && candidate.getTime() > now.getTime()) {
      const diffMs = candidate.getTime() - now.getTime();
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
      const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

      if (diffHours === 0) {
        return `in ${diffMins} min`;
      }
      if (diffMins === 0) {
        return `in ${diffHours} hr`;
      }
      return `in ${diffHours} hr ${diffMins} min`;
    }
  }

  return '';
}

// Backward compatibility aliases
export const formatTimeHindi = formatTimeEnglish;
export const formatRepeatDaysHindi = formatRepeatDaysEnglish;
