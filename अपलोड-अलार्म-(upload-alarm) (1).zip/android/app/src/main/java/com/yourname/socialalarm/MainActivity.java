package com.yourname.socialalarm;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
